<?php

use Illuminate\Support\Facades\Broadcast;

Broadcast::channel('App.Models.User.{id}', function ($user, $id) {
    return (int) $user->id === (int) $id;
});

// Broadcast::channel('chatroom', function () { return true; });

Broadcast::channel('chatroom.{receiver_id}', function ($user, $receiver_id) {  //$user is laravel build is variable jeta current user er data rakhe.
   return $user->id == $receiver_id;  //current userid ar event theke send kora id seme hole jekhan theke request korsea se message ta se pabe. 
}); //chatroom channel jekhan theke call hobe sekhan kar reciver id sob somoy kan pete sune thaksea keu kisu dissea ki nah dilei show korabe. 

Broadcast::channel('videocall.{receiver_id}', function ($user, $receiver_id) {
    return $user->id == $receiver_id;
});